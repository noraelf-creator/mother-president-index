CARD_PACK / 600x840 PNG
各カードの表裏をcards/に収録。割当先はcard_manifest.jsonのtargetSlotを参照。
スロット未指定はnull。盤面への自動合成は行いません。
このZIPはココフォリアのルームZIPではありません。画像素材として使用してください。
